export const PROD_MODE = false;
export const DISABLE_LOGS_MELLOWTEL = PROD_MODE;
export const DISABLE_LOGS_EXTENSION = PROD_MODE;
