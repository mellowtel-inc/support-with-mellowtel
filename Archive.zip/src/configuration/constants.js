export const KEY_SUPPORTED_USER_CONFIG = "KEY_SUPPORTED_USER_CONFIG";
export const DEFAULT_CONFIG_KEY = "54584498";
export const LAMBDA_URL =
  "https://uv62v6jashvutvgsitlbyjtrfa0pxsma.lambda-url.us-east-1.on.aws/";
